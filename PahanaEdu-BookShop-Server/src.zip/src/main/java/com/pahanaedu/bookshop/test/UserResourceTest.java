/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pahanaedu.bookshop.test;

/**
 *
 * @author Upeshika Sewwandi
 */
//public class UserResourceTest {
//    
//}
import com.pahanaedu.bookshop.dao.UserDAO;
import com.pahanaedu.bookshop.model.User;
import com.pahanaedu.bookshop.resource.UserResource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.Response;
import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserResourceTest {

    @Mock
    private UserDAO userDAO;

    @InjectMocks
    private UserResource userResource;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllUsersSuccess() {
        when(userDAO.getAll()).thenReturn(Arrays.asList(new User()));
        Response response = userResource.getAllUsers();
        assertEquals(200, response.getStatus());
    }

    @Test
    void testGetAllUsersFailure() {
        when(userDAO.getAll()).thenReturn(Arrays.asList());
        Response response = userResource.getAllUsers();
        assertEquals(404, response.getStatus());
    }

    @Test
    void testGetUserByIdSuccess() {
        when(userDAO.findById(1)).thenReturn(Optional.of(new User()));
        Response response = userResource.getUserById(1);
        assertEquals(200, response.getStatus());
    }

    @Test
    void testGetUserByIdFailure() {
        when(userDAO.findById(1)).thenReturn(Optional.empty());
        Response response = userResource.getUserById(1);
        assertEquals(404, response.getStatus());
    }

    @Test
    void testCreateUserSuccess() {
        User u = new User();
        when(userDAO.create(u)).thenReturn(true);
        Response response = userResource.createUser(u);
        assertEquals(201, response.getStatus());
    }

    @Test
    void testCreateUserFailure() {
        User u = new User();
        when(userDAO.create(u)).thenReturn(false);
        Response response = userResource.createUser(u);
        assertEquals(400, response.getStatus());
    }

    @Test
    void testUpdateUserSuccess() {
        User u = new User();
        when(userDAO.update(1, u)).thenReturn(true);
        Response response = userResource.updateUser(1, u);
        assertEquals(200, response.getStatus());
    }

    @Test
    void testUpdateUserFailure() {
        User u = new User();
        when(userDAO.update(1, u)).thenReturn(false);
        Response response = userResource.updateUser(1, u);
        assertEquals(404, response.getStatus());
    }

    @Test
    void testDeleteUserSuccess() {
        when(userDAO.delete(1)).thenReturn(true);
        Response response = userResource.deleteUser(1);
        assertEquals(200, response.getStatus());
    }

    @Test
    void testDeleteUserFailure() {
        when(userDAO.delete(1)).thenReturn(false);
        Response response = userResource.deleteUser(1);
        assertEquals(404, response.getStatus());
    }
}
