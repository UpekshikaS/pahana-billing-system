package com.pahanaedu.bookshop;

/**
 *
 * @author Upeshika Sewwandi
 */
public class PahanaEduBookShopServer {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
